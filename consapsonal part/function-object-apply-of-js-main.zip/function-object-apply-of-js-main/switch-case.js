const grade = 'A';

switch(grade){
    case 'A+':
        console.log("Good Job!");
        break;
    case 'A':
        console.log("Pretty good!");
        break;
    case 'B':
        console.log("Not bad!");
        break;
    case 'F':
        console.log("Failed!");
        break;
    default:
        console.log("Unknown grade");
}