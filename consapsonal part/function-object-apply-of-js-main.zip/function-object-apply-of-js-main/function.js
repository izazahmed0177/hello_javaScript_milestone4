// declear a function

function welcomeMsg(name){
    console.log("Hello, ", name);
}

// callling a function 
// welcomeMsg("Ananta Jalil");
// welcomeMsg("Hero alom");

// add two number. 

function addNumber(a, b){
    var result = a+b;
    return result;
}

console.log(addNumber(1, 2));
console.log(addNumber(5, 2));
console.log(addNumber(8, 2));
console.log(addNumber(1, 28));