// let age = 18;
// console.log(age);

// age = 19;
// console.log(age);

// age = 20;
// console.log(age);

// const x = 32;
// console.log(x);

// x = 33;
// console.log(x);

// var vs let

if(true){
    var x = 50;
}
console.log(x);

if(true){
    let y = 60;
}
console.log(y);