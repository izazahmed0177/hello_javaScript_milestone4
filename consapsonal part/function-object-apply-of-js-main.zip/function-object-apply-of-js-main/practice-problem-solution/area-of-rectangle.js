// Write a function named findArea() that will take height and width of a rectangle and will return the area of rectangle.

function findArea(height, width) {
    const area = height * width;
    return area;
}

const areaOfRectangle = findArea(4, 5);
console.log(areaOfRectangle);