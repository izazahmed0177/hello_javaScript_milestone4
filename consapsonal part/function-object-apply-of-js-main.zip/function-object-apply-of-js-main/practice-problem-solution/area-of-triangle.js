function findArea(base, height){
    const area = 0.5 * base * height;
    return area;
}

const areaOfTriangle = findArea(3, 4);
console.log(areaOfTriangle);