// Write a function which will take an integer and will return the square of a number.

function squareNum(num){
    return num * num;
}

console.log(squareNum(5));