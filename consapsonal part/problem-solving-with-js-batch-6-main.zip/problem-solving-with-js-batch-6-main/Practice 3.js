// Count the number of vowels in a string
